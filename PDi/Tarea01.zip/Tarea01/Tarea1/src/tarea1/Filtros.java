/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.LinkedList;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author hectorsama
 */
public class Filtros {

    private BufferedImage imagen;

    private BufferedImage original;
    private BufferedImage img = null;

    public BufferedImage cargarImagen() {
        //Variable que regresara la imagen 

        //Abrir venata para buscar imagen
        JFileChooser search = new JFileChooser();
        //Titulo de la ventana
        search.setDialogTitle("Cargar Imagen");
        FileNameExtensionFilter fne = new FileNameExtensionFilter("JPG & GIF & BMP",
                "jpg", "gif", "bmp");
        search.setFileFilter(fne);
        int dialog = search.showOpenDialog(null);

        if (dialog == JFileChooser.APPROVE_OPTION) {

            //Leemos la imagen
            try {
                File archivo = search.getSelectedFile();
                img = ImageIO.read(archivo);
            } catch (Exception e) {
                System.out.println("Error ");
            }

        }
        imagen = img;
        return img;

    }

    public BufferedImage copia() {
        BufferedImage copia = new BufferedImage(img.getWidth(),
                img.getHeight(), BufferedImage.TYPE_INT_BGR);
        Graphics g = copia.createGraphics();
        g.drawImage(img, 0, 0, null);
        imagen = copia;
        return copia;
    }

    /*
    Filtro Rojo
    Recorremos la imagen y vamos aplicando el color rojo a cada uno de los pixeles
    de la imagen.
     */
    public BufferedImage rojo() {

        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                int aux = imagen.getRGB(i, j);
                int rojo = (aux & 0xFF0000) >> 16;
                aux = rojo << 16;

                imagen.setRGB(i, j, aux);
            }
        }

        return imagen;
    }

    /*
    Filtro Verde
    Recorremos la imagen y vamos aplicando el color verde a cada uno de los pixeles
    de la imagen.
     */

    public BufferedImage verde() {

        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                int aux = imagen.getRGB(i, j);
                int rojo = (aux & 0xFF0000) >> 16;
                aux = rojo << 8;
                imagen.setRGB(i, j, aux);
            }
        }

        return imagen;
    }

    /*
    Filtro Azul
    Recorremos la imagen y vamos aplicando el color azul a cada uno de los pixeles
    de la imagen.
     */

    public BufferedImage azul() {

        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                int aux = imagen.getRGB(i, j);
                int blue = aux & 0xFF;
                aux = blue;
                imagen.setRGB(i, j, aux);
            }
        }

        return imagen;
    }

    /*
    Filtro Gris
    Recorremos la imagen y vamos aplicando el color gris a cada uno de los pixeles
    de la imagen.
     */
    public BufferedImage gris() {
        int aux;
        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color c = new Color(this.imagen.getRGB(i, j));
                aux = (int) ((c.getRed() + c.getGreen() + c.getBlue()) / 3);
                int p = (aux << 16) | (aux << 8) | aux;

                imagen.setRGB(i, j, p);
            }
        }

        return imagen;
    }

    /*
    Filtro Gris
    Recorremos la imagen y vamos aplicando el color gris a cada uno de los pixeles
    de la imagen.
     */
    public BufferedImage grsi1() {

        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color c = new Color(this.imagen.getRGB(i, j));
                int gray = (int) (c.getRed() * 0.3 + c.getGreen() * 0.59 + c.getBlue() * 0.11);
                int p = (gray << 24) | (gray << 16) | (gray << 8) | gray;

                imagen.setRGB(i, j, p);
            }
        }

        return imagen;
    }

    /*
    Filtro Gris
    Recorremos la imagen y vamos aplicando el color gris a cada uno de los pixeles
    de la imagen. 
     */
    public BufferedImage gris2() {
        int aux;
        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color c = new Color(this.imagen.getRGB(i, j));
                aux = (int) ((c.getRed() + c.getGreen()) / 2);
                int p = (aux << 16) | (aux << 8) | aux;
                imagen.setRGB(i, j, p);
            }
        }

        return imagen;
    }

    /*
    Filtro Gris
    Recorremos la imagen y vamos aplicando el color gris a cada uno de los pixeles
    de la imagen. 
     */
    public BufferedImage gris3() {
        int aux;
        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color c = new Color(this.imagen.getRGB(i, j));
                aux = (int) ((c.getRed() + c.getBlue()) / 2);
                int p = (aux << 16) | (aux << 8) | aux;
                imagen.setRGB(i, j, aux);
            }
        }

        return imagen;
    }

    /*
    Filtro Gris
    Recorremos la imagen y vamos aplicando el color gris a cada uno de los pixeles
    de la imagen. En este caso (b+g)/2
     */
    public BufferedImage gris4() {
        int aux;
        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color c = new Color(this.imagen.getRGB(i, j));
                aux = (int) ((c.getBlue() + c.getGreen()) / 2);
                int p = (aux << 16) | (aux << 8) | aux;
                imagen.setRGB(i, j, p);
            }
        }

        return imagen;
    }

    /*
    Filtro Brillo
    Recorremos la imagen y vamos aplicando brillo a cada uno de los pixeles
    de la imagen.
     */
    public BufferedImage brillo(int k) {
        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color aux = new Color(imagen.getRGB(i, j));
                int r = aux.getRed() + k;
                int g = aux.getGreen() + k;
                int b = aux.getBlue() + k;
                r = nivel(r);
                g = nivel(g);
                b = nivel(b);
                Color color_nuevo = new Color(r, g, b);
                imagen.setRGB(i, j, color_nuevo.getRGB());
            }
        }
        return imagen;
    }

    /*
    Filtro Inverso
     */
    public BufferedImage inverso() {
        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color aux = new Color(imagen.getRGB(i, j));
                int promedio = (aux.getRed() + aux.getGreen() + aux.getBlue()) / 3;
                if (promedio < 127) {
                    aux = new Color(255, 255, 255);
                } else {
                    aux = new Color(0, 0, 0);
                }
                imagen.setRGB(i, j, aux.getRGB());
            }
        }
        return imagen;
    }

    /**
     * Filtro que aplica el filtro de alto constraste a una imagen
     */
    public BufferedImage altoContraste() {
        for (int i = 0; i < imagen.getWidth(); i++) {
            for (int j = 0; j < imagen.getHeight(); j++) {
                Color aux = new Color(imagen.getRGB(i, j));
                int promedio = (aux.getRed() + aux.getGreen() + aux.getBlue()) / 3;
                if (promedio < 127) {
                    aux = new Color(0, 0, 0);
                } else {
                    aux = new Color(255, 255, 255);
                }
                imagen.setRGB(i, j, aux.getRGB());
            }
        }
        return imagen;
    }
    //Metodo para tener una acota del nivel de brillo

    private int nivel(int x) {
        if (x < 0) {
            return 0;
        }
        if (x > 255) {
            return 255;
        }
        return x;
    }

}
